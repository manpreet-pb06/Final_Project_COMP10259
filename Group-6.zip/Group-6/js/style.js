$(document).ready(function() {
    // Initialize the Slick carousel for the gallery images
    $(window).scroll(function() {
        var scroll = $(window).scrollTop();
        var headerHeight = $('.nav').outerHeight();
    
        if (scroll >= headerHeight) {
          $('.nav').addClass('fixed');
        } else {
          $('.nav').removeClass('fixed');
        }
      });

    $('.gallery-images').slick({
      dots: true,
      autoplay: true,
      autoplaySpeed: 2000,
    });
    $('.lightbox .close-button').click(function() {
        $('.lightbox').hide();
      });
    
      // Close the lightbox when clicking anywhere outside it
      $(document).mouseup(function(e) {
        var lightbox = $('.lightbox');
        if (!lightbox.is(e.target) && lightbox.has(e.target).length === 0) {
          lightbox.hide();
        }
      });
  });
  